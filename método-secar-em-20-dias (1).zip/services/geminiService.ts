import { GoogleGenAI } from "@google/genai";

// Initialize the API client
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getMotivationTip = async (obstacle: string): Promise<string> => {
  try {
    const modelId = "gemini-2.5-flash";
    const prompt = `
      Você é um coach de emagrecimento motivacional e empático. 
      O usuário está enfrentando o seguinte obstáculo: "${obstacle}".
      Dê uma dica curta, inspiradora e acionável (máximo 2 frases) para ajudar a pessoa a superar isso agora.
      Use um tom encorajador.
    `;

    const response = await ai.models.generateContent({
      model: modelId,
      contents: prompt,
    });

    return response.text || "Continue firme! Cada passo conta para a sua jornada.";
  } catch (error) {
    console.error("Erro ao consultar Gemini:", error);
    return "O primeiro passo é sempre o mais difícil, mas você é capaz de continuar!";
  }
};