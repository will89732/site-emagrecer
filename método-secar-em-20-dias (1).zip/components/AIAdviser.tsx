import React, { useState } from 'react';
import { Sparkles, MessageCircle, Send } from 'lucide-react';
import { getMotivationTip } from '../services/geminiService';

export const AIAdviser: React.FC = () => {
  const [input, setInput] = useState('');
  const [response, setResponse] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    setLoading(true);
    const tip = await getMotivationTip(input);
    setResponse(tip);
    setLoading(false);
  };

  return (
    <section className="py-16 bg-gradient-to-br from-emerald-900 to-slate-900 text-white">
      <div className="mx-auto max-w-4xl px-6 lg:px-8 text-center">
        <div className="flex items-center justify-center gap-2 mb-4">
            <Sparkles className="text-yellow-400 h-6 w-6 animate-pulse" />
            <h2 className="text-2xl font-bold">Coach Inteligente 24h</h2>
        </div>
        
        <p className="text-emerald-200 mb-8">
          Está em dúvida se consegue? Conte para nossa IA qual é o seu maior obstáculo hoje (ex: "tenho preguiça de cozinhar" ou "amo doces") e receba uma dica exclusiva do "Método Secar Em 20 Dias".
        </p>

        <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 md:p-8 max-w-2xl mx-auto shadow-2xl border border-white/10">
            {!response ? (
                <form onSubmit={handleSubmit} className="flex flex-col gap-4">
                    <label htmlFor="obstacle" className="sr-only">Seu obstáculo</label>
                    <div className="relative">
                        <input
                            type="text"
                            id="obstacle"
                            value={input}
                            onChange={(e) => setInput(e.target.value)}
                            placeholder="Ex: Não tenho tempo para treinar..."
                            className="w-full rounded-xl bg-slate-800/50 border border-slate-600 text-white placeholder-slate-400 px-4 py-4 focus:ring-2 focus:ring-emerald-500 focus:border-transparent outline-none transition-all"
                        />
                        <button 
                            type="submit" 
                            disabled={loading || !input}
                            className="absolute right-2 top-2 bottom-2 bg-emerald-500 hover:bg-emerald-400 text-white rounded-lg px-4 flex items-center justify-center transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                            {loading ? (
                                <div className="h-5 w-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                            ) : (
                                <Send className="h-5 w-5" />
                            )}
                        </button>
                    </div>
                </form>
            ) : (
                <div className="animate-fade-in text-left">
                     <div className="flex items-start gap-3">
                        <div className="bg-emerald-500 p-2 rounded-full mt-1 shrink-0">
                            <MessageCircle className="h-5 w-5 text-white" />
                        </div>
                        <div>
                            <h3 className="font-bold text-lg text-emerald-300 mb-1">Dica do Coach:</h3>
                            <p className="text-lg leading-relaxed text-slate-100 italic">"{response}"</p>
                            <button 
                                onClick={() => { setResponse(null); setInput(''); }}
                                className="mt-4 text-sm text-emerald-400 hover:text-emerald-300 underline underline-offset-4"
                            >
                                Perguntar outra coisa
                            </button>
                        </div>
                     </div>
                </div>
            )}
        </div>
      </div>
    </section>
  );
};