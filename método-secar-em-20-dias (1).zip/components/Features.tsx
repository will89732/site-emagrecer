import React from 'react';
import { Smartphone, Users, BookOpen, Activity, Zap, Heart } from 'lucide-react';

const featureList = [
  {
    title: 'Aplicativo de Bolso',
    description: 'Acesse o cronograma de 20 dias, receitas e contador de calorias na palma da mão.',
    icon: Smartphone,
  },
  {
    title: 'Grupo VIP com Aulas',
    description: 'Acesso exclusivo a lives e comunidade secreta (Somente no plano Completo).',
    icon: Users,
  },
  {
    title: 'Biblioteca de E-books',
    description: 'Receitas Fit, Sucos Detox e Cardápios Seca-Barriga para acelerar.',
    icon: BookOpen,
  },
  {
    title: 'Monitoramento Real',
    description: 'Gráficos de peso e medidas para você ver a diferença em 20 dias.',
    icon: Activity,
  },
  {
    title: 'Desafios Diários',
    description: 'Tarefas simples todos os dias para manter você no foco do emagrecimento.',
    icon: Zap,
  },
  {
    title: 'Mindset Vencedor',
    description: 'Áudios e textos para reprogramar sua mente contra a ansiedade.',
    icon: Heart,
  },
];

export const Features: React.FC = () => {
  return (
    <section className="py-24 bg-white">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="mx-auto max-w-2xl lg:text-center">
          <h2 className="text-base font-semibold leading-7 text-emerald-600">O segredo revelado</h2>
          <p className="mt-2 text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl">
            Tudo o que você precisa para chegar no objetivo
          </p>
          <p className="mt-6 text-lg leading-8 text-slate-600">
            O Método Secar Em 20 Dias não é só uma dieta, é um ecossistema completo focado no seu resultado rápido e duradouro.
          </p>
        </div>
        
        <div className="mx-auto mt-16 max-w-2xl sm:mt-20 lg:mt-24 lg:max-w-none">
          <dl className="grid max-w-xl grid-cols-1 gap-x-8 gap-y-16 lg:max-w-none lg:grid-cols-3">
            {featureList.map((feature) => (
              <div key={feature.title} className="flex flex-col bg-slate-50 rounded-2xl p-8 hover:shadow-lg transition-shadow duration-300">
                <dt className="flex items-center gap-x-3 text-base font-semibold leading-7 text-slate-900">
                  <div className="h-10 w-10 flex items-center justify-center rounded-lg bg-emerald-600">
                     <feature.icon className="h-6 w-6 text-white" aria-hidden="true" />
                  </div>
                  {feature.title}
                </dt>
                <dd className="mt-4 flex flex-auto flex-col text-base leading-7 text-slate-600">
                  <p className="flex-auto">{feature.description}</p>
                </dd>
              </div>
            ))}
          </dl>
        </div>
      </div>
    </section>
  );
};