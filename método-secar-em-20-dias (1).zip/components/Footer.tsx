import React from 'react';
import { Instagram } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-white border-t border-slate-200">
      <div className="mx-auto max-w-7xl px-6 py-12 flex flex-col items-center justify-center lg:px-8">
        <div className="flex justify-center space-x-6 mb-4">
          <a href="#" className="text-slate-400 hover:text-emerald-600 transition-colors transform hover:scale-110">
            <span className="sr-only">Instagram</span>
            <Instagram className="h-8 w-8" />
          </a>
        </div>
        <div className="text-center">
          <p className="text-sm leading-5 text-slate-500">
            &copy; 2024 Método Secar Em 20 Dias. Todos os direitos reservados.
          </p>
          <p className="mt-2 text-xs text-slate-400">
             Este site não é afiliado ao Facebook ou a qualquer entidade do Instagram.<br/>
             Os resultados podem variar de pessoa para pessoa.
          </p>
        </div>
      </div>
    </footer>
  );
};