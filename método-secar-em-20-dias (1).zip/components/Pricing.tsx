import React from 'react';
import { Check, X, Star } from 'lucide-react';

interface PricingTier {
  name: string;
  price: string;
  description: string;
  features: string[];
  notIncluded: string[];
  cta: string;
  link: string; // Novo campo para o link
  mostPopular?: boolean;
  highlight?: boolean;
}

const tiers: PricingTier[] = [
  {
    name: 'Start',
    price: '27,90',
    description: 'Para quem quer apenas a ferramenta básica.',
    features: [
      'Acesso ao Aplicativo',
      'Cronograma 20 Dias',
      'Contador de Calorias',
    ],
    notIncluded: [
      'Protocolo Detox Turbo',
      'Grupo VIP de Alunas',
      'Aulas Exclusivas',
      'Biblioteca de E-books'
    ],
    cta: 'Quero Apenas o App',
    link: 'https://pay.kiwify.com.br/IhX5Pmh?afid=a1vuPDTX', // COLOQUE SEU LINK AQUI
    mostPopular: false
  },
  {
    name: 'Turbo',
    price: '37,90',
    description: 'O aplicativo + O segredo do Detox.',
    features: [
      'Acesso ao Aplicativo',
      'Cronograma 20 Dias',
      'Protocolo Detox Turbo (Bônus)', // Marketing Hook
      'Lista de Compras Econômica' 
    ],
    notIncluded: [
      'Grupo VIP de Alunas',
      'Aulas Exclusivas',
      'Biblioteca de E-books'
    ],
    cta: 'Quero App + Detox',
    link: 'https://pay.kiwify.com.br/dBz3cJt?afid=a1vuPDTX', // COLOQUE SEU LINK AQUI
    mostPopular: false,
  },
  {
    name: 'Método Completo VIP',
    price: '45,90',
    description: 'A experiência definitiva. Tudo incluso.',
    features: [
      'Acesso ao Aplicativo',
      'Cronograma 20 Dias',
      'Protocolo Detox Turbo',
      'Grupo VIP de Alunas (Exclusivo)', // High Value
      'Aulas com Especialistas (Exclusivo)', // High Value
      'Biblioteca de 5 E-books (Exclusivo)', // High Value
      'Suporte Prioritário'
    ],
    notIncluded: [],
    cta: 'QUERO O PACOTE COMPLETO',
    link: 'https://pay.kiwify.com.br/6XUzyee?afid=a1vuPDTX', // COLOQUE SEU LINK AQUI
    mostPopular: true,
    highlight: true
  }
];

export const Pricing: React.FC = () => {
  return (
    <section id="pricing" className="py-24 bg-slate-50">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center mb-16">
          <h2 className="text-base font-semibold leading-7 text-emerald-600">Oferta Especial de Lançamento</h2>
          <p className="mt-2 text-4xl font-bold tracking-tight text-slate-900 sm:text-5xl">
            Escolha seu resultado
          </p>
          <p className="mt-6 text-lg leading-8 text-slate-600">
            Veja como por uma pequena diferença você leva o <strong>Método Completo</strong> com Grupo e Aulas.
          </p>
        </div>

        <div className="isolate mx-auto grid max-w-md grid-cols-1 gap-8 lg:mx-0 lg:max-w-none lg:grid-cols-3">
          {tiers.map((tier) => (
            <div 
              key={tier.name}
              className={`rounded-3xl p-8 xl:p-10 ring-1 transition-all duration-300 flex flex-col justify-between relative
                ${tier.highlight 
                  ? 'bg-white ring-2 ring-emerald-600 shadow-2xl scale-105 z-10' 
                  : 'bg-slate-50 ring-slate-200 hover:bg-white hover:shadow-lg z-0'}
              `}
            >
              <div>
                {tier.mostPopular && (
                  <div className="absolute -top-5 left-0 right-0 mx-auto w-fit rounded-full bg-gradient-to-r from-emerald-500 to-emerald-700 px-4 py-1 text-sm font-bold text-white shadow-md flex items-center gap-1">
                    <Star className="h-4 w-4 fill-current" /> MAIS VENDIDO
                  </div>
                )}
                
                <div className="flex items-center justify-between gap-x-4">
                  <h3 id={tier.name} className={`text-xl font-bold leading-8 ${tier.highlight ? 'text-emerald-700' : 'text-slate-900'}`}>
                    {tier.name}
                  </h3>
                </div>
                
                <p className="mt-4 text-sm leading-6 text-slate-600 min-h-[48px]">{tier.description}</p>
                
                <p className="mt-6 flex items-baseline gap-x-1">
                  <span className="text-5xl font-extrabold tracking-tight text-slate-900">R$ {tier.price}</span>
                  <span className="text-sm font-semibold leading-6 text-slate-600">/único</span>
                </p>

                <ul role="list" className="mt-8 space-y-3 text-sm leading-6 text-slate-600">
                  {tier.features.map((feature) => (
                    <li key={feature} className="flex gap-x-3">
                      <Check className={`h-6 w-5 flex-none ${tier.highlight ? 'text-emerald-600' : 'text-slate-500'}`} aria-hidden="true" />
                      <span className={feature.includes('Exclusivo') ? 'font-bold text-slate-900' : ''}>{feature}</span>
                    </li>
                  ))}
                  {tier.notIncluded.map((feature) => (
                    <li key={feature} className="flex gap-x-3 text-slate-400">
                      <X className="h-6 w-5 flex-none text-slate-300" aria-hidden="true" />
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>
              
              <a
                href={tier.link}
                target="_blank"
                rel="noopener noreferrer"
                aria-describedby={tier.name}
                className={`mt-8 block rounded-xl py-4 px-3 text-center text-base font-bold leading-6 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 transition-all transform hover:-translate-y-1
                  ${tier.highlight 
                    ? 'bg-emerald-600 text-white hover:bg-emerald-500 shadow-lg hover:shadow-emerald-500/30 focus-visible:outline-emerald-600' 
                    : 'bg-white border-2 border-emerald-100 text-emerald-700 hover:border-emerald-200 hover:bg-emerald-50'}
                `}
              >
                {tier.cta}
              </a>
            </div>
          ))}
        </div>
        
        <div className="mt-12 text-center bg-yellow-50 p-4 rounded-xl border border-yellow-200 max-w-3xl mx-auto">
            <p className="text-sm text-yellow-800 font-medium">
                ⚠️ Atenção: As vagas para o Grupo VIP (Plano de R$ 45,90) estão 94% preenchidas. Garanta sua vaga hoje.
            </p>
        </div>
      </div>
    </section>
  );
};