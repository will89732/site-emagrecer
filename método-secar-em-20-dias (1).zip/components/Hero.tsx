import React from 'react';
import { ArrowRight, Star } from 'lucide-react';

export const Hero: React.FC = () => {
  const scrollToPricing = () => {
    const element = document.getElementById('pricing');
    if (element) element.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="relative bg-emerald-900 text-white overflow-hidden pb-20 pt-24 lg:pb-32 lg:pt-40">
      <div className="absolute inset-0 z-0 opacity-20">
         <img 
            src="https://picsum.photos/1920/1080?grayscale&blur=2" 
            alt="Background Gym" 
            className="w-full h-full object-cover"
         />
      </div>
      
      <div className="relative z-10 mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 flex flex-col items-center text-center">
        <div className="mb-6 inline-flex items-center rounded-full bg-emerald-800/80 px-4 py-1.5 border border-emerald-600 backdrop-blur-sm">
          <span className="flex h-2 w-2 rounded-full bg-emerald-400 mr-2 animate-pulse"></span>
          <span className="text-sm font-semibold text-emerald-100 uppercase tracking-wide">Protocolo Oficial Validado</span>
        </div>
        
        <h1 className="mx-auto max-w-4xl text-5xl font-extrabold tracking-tight text-white sm:text-7xl">
          Transforme seu corpo com o <span className="text-emerald-400 block sm:inline">Método Secar Em 20 Dias.</span>
        </h1>
        
        <p className="mx-auto mt-6 max-w-2xl text-lg text-emerald-100">
          Sem dietas malucas. Um plano passo a passo, aplicativo exclusivo e grupo de suporte para você eliminar o inchaço e recuperar sua autoestima em menos de 3 semanas.
        </p>
        
        <div className="mt-10 flex flex-col gap-4 sm:flex-row justify-center items-center">
          <button 
            onClick={scrollToPricing}
            className="group inline-flex items-center justify-center rounded-full bg-white px-8 py-4 text-lg font-bold text-emerald-900 transition-all hover:bg-emerald-50 hover:scale-105 focus:outline-none focus:ring-2 focus:ring-emerald-400 focus:ring-offset-2 focus:ring-offset-emerald-900"
          >
            Quero Secar Agora
            <ArrowRight className="ml-2 h-5 w-5 transition-transform group-hover:translate-x-1" />
          </button>
          
          <div className="flex items-center gap-2 text-sm font-medium text-emerald-200">
            <div className="flex -space-x-1">
               {[1,2,3,4].map(i => (
                   <img key={i} className="h-8 w-8 rounded-full ring-2 ring-emerald-900" src={`https://picsum.photos/50/50?random=${i}`} alt="User" />
               ))}
            </div>
            <div className="flex flex-col items-start ml-2">
                <div className="flex text-yellow-400">
                    <Star className="h-4 w-4 fill-current" />
                    <Star className="h-4 w-4 fill-current" />
                    <Star className="h-4 w-4 fill-current" />
                    <Star className="h-4 w-4 fill-current" />
                    <Star className="h-4 w-4 fill-current" />
                </div>
                <span>4.9/5 de satisfação</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};